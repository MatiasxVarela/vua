<?php
function redireccionar ($url)
{
	header('Location: '.$url);
}
?>